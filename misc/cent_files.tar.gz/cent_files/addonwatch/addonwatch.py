import os, fnmatch
import sys
import pyinotify


class EventProcessor(pyinotify.ProcessEvent):
    _methods = ["IN_CREATE",
                "IN_DELETE",
                "IN_DELETE_SELF",
                "IN_MODIFY",
                "IN_MOVED_TO"]

def process_generator(cls, method):

    def _method_name(self, event):
        obj = os.scandir('/var/www/html/astpp/playlist/example/media/recordings/')
        obj2 = os.scandir('/usr/local/freeswitch/scripts/astpp/lib/addons/')
        if obj2 or obj:
            file1 = open("/opt/ASTPP/freeswitch/scripts/addons.lua","w")
            for entry in obj2:
                if entry.name.endswith('.lua') and entry.is_file():
                    print("dofile(\"/usr/local/freeswitch/scripts/astpp/lib/addons/"+entry.name+"\")",file = file1)
            file1.close()
            file2 = 'chmod -Rf 777 '+ event.pathname
            os.system(file2)
    _method_name.__name__ = "process_{}".format(method)
    setattr(cls, _method_name.__name__, _method_name)

for method in EventProcessor._methods:
    process_generator(EventProcessor, method)

watch_manager = pyinotify.WatchManager()
event_notifier = pyinotify.Notifier(watch_manager, EventProcessor())

watch_this = os.path.abspath("/usr/local/freeswitch/scripts/astpp/lib/addons/")
watch_this2 = os.path.abspath("/var/www/html/astpp/playlist/example/media/recordings/")
watch_manager.add_watch(watch_this, pyinotify.ALL_EVENTS)
watch_manager.add_watch(watch_this2, pyinotify.ALL_EVENTS)
event_notifier.loop()
